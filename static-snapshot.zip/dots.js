 /* --- WAIT FOR PAGE TO LOAD --- */
document.addEventListener("DOMContentLoaded", async function () {
    
    /* --- LOAD PARTICLES --- */
    await tsParticles.load("tsparticles", {
        fpsLimit: 60,
        background: {
            color: "#111" // Dark Background
        },
        interactivity: {
            events: {
                onHover: { enable: true, mode: "repulse" },
                resize: true
            }
        },
        particles: {
            color: { value: "#ffffff" },
            links: {
                enable: true,
                color: "#ffffff",
                distance: 150,
                opacity: 0.5,
                width: 1
            },
            move: {
                enable: true,
                speed: 2
            },
            number: {
                value: 80,
                density: { enable: true, area: 800 }
            },
            opacity: { value: 0.5 },
            shape: { type: "circle" },
            size: { value: { min: 1, max: 5 } }
        },
        detectRetina: true
    });

    console.log("Particles Loaded Successfully!");
});


/* --- SEARCH FUNCTION (Keep this too) --- */
function filterGames() {
    var input = document.getElementById('gameSearch');
    var filter = input.value.toUpperCase();
    var container = document.getElementsByClassName('game-buttons')[0];
    // Fallback if class not found, try ID
    if (!container) container = document.getElementById('gameList');
    
    if (container) {
        var links = container.getElementsByTagName('a');
        for (var i = 0; i < links.length; i++) {
            var button = links[i].getElementsByTagName('button')[0];
            if (button) {
                var txtValue = button.textContent || button.innerText;
                if (txtValue.toUpperCase().indexOf(filter) > -1) {
                    links[i].style.display = "";
                } else {
                    links[i].style.display = "none";
                }
            }
        }
    }
}