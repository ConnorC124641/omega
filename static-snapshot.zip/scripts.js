function filterGames() {
    // 1. Get input and elements
    var input = document.getElementById('gameSearch');
    var filter = input.value.toUpperCase();
    var container = document.getElementsByClassName('game-buttons')[0];
    var links = container.getElementsByTagName('a');
    
    // 2. Create a flag to track if we found anything
    var anyGameFound = false;

    // 3. Loop through all games
    for (var i = 0; i < links.length; i++) {
        var button = links[i].getElementsByTagName('button')[0];
        var txtValue = button.textContent || button.innerText;

        if (txtValue.toUpperCase().indexOf(filter) > -1) {
            links[i].style.display = ""; // Show game
            anyGameFound = true;         // Mark that we found at least one
        } else {
            links[i].style.display = "none"; // Hide game
        }
    }

    // 4. Show or Hide the "No games found" message
    var messageElement = document.getElementById("no-games-message");
    
    if (anyGameFound === true) {
        messageElement.style.display = "none";  // Hide message if games exist
    } else {
        messageElement.style.display = "block"; // Show message if list is empty
    }
}/* --- 1. PARTICLE BACKGROUND CONFIGURATION --- */
// This creates the "dots connected by lines" effect
tsParticles.load("tsparticles", {
  fpsLimit: 60,
  background: {
    color: "#111" // Dark background color
  },
  interactivity: {
    events: {
      onHover: {
        enable: true,
        mode: "repulse" // Dots run away when you hover over them
      },
      resize: true
    },
    modes: {
      repulse: {
        distance: 100,
        duration: 0.4
      }
    }
  },
  particles: {
    color: {
      value: "#ffffff" // White dots
    },
    links: {
      enable: true,      // THIS IS THE KEY: Enables the lines
      color: "#ffffff",
      distance: 150,     // Max distance to draw a line
      opacity: 0.5,
      width: 1
    },
    move: {
      enable: true,
      speed: 2,         // How fast they move
      direction: "none",
      random: false,
      straight: false,
      outModes: "out"
    },
    number: {
      density: {
        enable: true,
        area: 800
      },
      value: 80         // Number of dots (increase for more chaos)
    },
    opacity: {
      value: 0.5
    },
    shape: {
      type: "circle"
    },
    size: {
      value: { min: 1, max: 5 }
    }
  },
  detectRetina: true
});

/* --- 2. GAME SEARCH FUNCTION --- */
function filterGames() {
    // Get the text user typed
    var input = document.getElementById('gameSearch');
    var filter = input.value.toUpperCase();
    
    // Get the list of games
    var container = document.getElementById('gameList');
    var links = container.getElementsByTagName('a'); 
    
    // Check if any games match
    var gamesFound = false;

    // Loop through all game buttons
    for (var i = 0; i < links.length; i++) {
        var button = links[i].getElementsByTagName('button')[0];
        var txtValue = button.textContent || button.innerText;
        
        // If the game name matches the search...
        if (txtValue.toUpperCase().indexOf(filter) > -1) {
            links[i].style.display = ""; // Show it
            gamesFound = true;
        } else {
            links[i].style.display = "none"; // Hide it
        }
    }

    // Show/Hide "No games found" message
    var message = document.getElementById("no-games-message");
    if (gamesFound) {
        message.style.display = "none";
    } else {
        message